document.getElementById("editPetForm").addEventListener("submit", function(event) {
    event.preventDefault();

    const formData = new FormData(this);

    fetch("http://localhost:4000/pet/edit", {
        method: "POST",
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.status) {
            alert("Pet updated successfully");
              // Reload the page after a delay
              setTimeout(() => {
                location.reload();
            }, 1000);
        } else {
            alert("Failed to update pet: " + data.msg);
        }
    })
    .catch(error => {
        console.error("Error editing pet:", error);
        alert("An error occurred while updating the pet.");
    });
});

function deletePet() {
    const did = document.getElementById("did").value;

    fetch("http://localhost:4000/pet/delete", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ id: did })
    })
    .then(response => response.json())
    .then(data => {
        if (data.status) {
            alert("Pet deleted successfully");
              // Reload the page after a delay
              setTimeout(() => {
                location.reload();
            }, 1000);
        } else {
            alert("Failed to delete pet: " + data.msg);
        }
    })
    .catch(error => {
        console.error("Error deleting pet:", error);
        alert("An error occurred while deleting the pet.");
    });
}

function submitForm() {
    var formData = new FormData(document.getElementById('addPetForm'));

    $.ajax({
        url: 'http://localhost:4000/pet/add',
        type: 'POST',
        data: formData,
        contentType: false,
        processData: false,
        success: function(response) {
            alert('Pet added successfully');
              // Reload the page after a delay
              setTimeout(() => {
                location.reload();
            }, 1000);
        },
        error: function(xhr, status, error) {
            alert('Error: ' + error);
        }
    });
}


function fetchPetList() {
    $.get('http://localhost:4000/list/pets', function(response) {
        $('#petList').empty();
        response.pets.forEach(function(pet) {
            var card = $('<div>').addClass('pet-card');
            var image = $('<img>').attr('src', pet.image).attr('alt', pet.name).data('pet-id', pet.petId).click(function() {
                fillEditForm($(this).data('pet-id')); // Add click event to each pet image
            });
            var name = $('<p>').text(pet.name);
            var breed = $('<p>').text('Breed: ' + pet.breed);
            var gender = $('<p>').text('Gender: ' + pet.gender);
            var petId = $('<p>').text('Pet ID: ' + pet.petId); // Include petId

            card.append(image, name, breed, gender, petId);
            $('#petList').append(card);
        });
    });
}

function fillEditForm(petId) {
    $.get(`http://localhost:4000/pet/${petId}`, function(response) {
        // Populate the edit form with the fetched pet's details
        $('#edit_id').val(response.pet.id); // Autofill the petId field
        $('#did').val(response.pet.id); // Autofill the petId field
        $('#edit_name').val(response.pet.name);
        $('#edit_age').val(response.pet.age);
        $('#edit_breed').val(response.pet.breed);
        $('#edit_gender').val(response.pet.gender);
        $('#edit_Adoption_status').val(response.pet.Adoption_status);
        $('#edit_category').val(response.pet.category);
        // You may need to handle the image separately if you want to display it in the edit form
    }).fail(function() {
        alert('Failed to fetch pet details for editing.');
    });
}



function searchAndViewPet() {
    var searchName = $('#searchPet').val();
    $.get(`http://localhost:4000/search-and-view/pet?name=${searchName}`, function(response) {
        $('#searchAndViewResult').html(`
            <div>
                <h3>${response.pet.name}</h3>
                <p>Pet ID: ${response.pet.petId}</p>
                <p>Age: ${response.pet.age}</p>
                <p>Breed: ${response.pet.breed}</p>
                <p>Gender: ${response.pet.gender}</p>
                
                <p>Category: ${response.pet.category}</p>
                <img src="${response.pet.image}" alt="${response.pet.name}" class="pet-image">
            </div>
        `);
    }).fail(function() {
        $('#searchAndViewResult').html('<p>No pet found with that name.</p>');
    });
}